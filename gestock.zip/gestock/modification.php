<?php
$servername = "localhost";
$username = "root";
$password = ""

try { //Connexion bdd
  $db = new PDO("mysql:host=localhost;dbname=gestock", $username, $password);
  /* // Affichele donnée du categorie
  foreach ($db->query('SELECT * FROM categorie') as $row) {
    print_r($row);
  }*/
} catch(PDOException $e) {

  print "Erreur: " . $e->getMessage();
  die;
}
?> 