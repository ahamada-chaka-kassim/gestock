<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<h1>Bienvenu</h1>
<?php include 'login.php'; ?>



    <div class="logo">
        <img src="../logo.png" alt="">
    </div>
        <div class="main-container">
       
        <div class="connection">
            <p>CONNEXION</p>
                <form method="post">

                    <div class="form-content1">
                        <p>Nom d'utilsateur</p>
                        <input type="username" name="Username" id="Username">
                    </div>

                    <div class="form-content2">
                        <p>Mot de passe</p>
                        <input type="password" name="Password" id="Password">
                    </div>
                    
                    <div class="form-content3">
                        <a href="" type="submit" name="connect" id="connect" class="connection-btn">Connexion</a>
                    </div>
                    
                </form>
        
        </div>
    </div>
</body>
</html>