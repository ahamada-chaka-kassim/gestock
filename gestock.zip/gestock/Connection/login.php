<?php
$host = "localhost";
$user = "root";
$password = "";
$database="gestock";

try { //Connexion bdd
  $bd = new PDO("mysql:host=localhost;dbname=gestock", $user, $password);

  $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connecté"; 
} catch(PDOException $e) {

  echo "Erreur: " . $e->getMessage();
  
}






?> 